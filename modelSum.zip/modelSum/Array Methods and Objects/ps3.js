// Write a program to create an array of 2 sports. Use unshift() to add 3 more sports to the beginning in a single line and print the array.

sports=["cricket","carram","hockey"]

sports.unshift("tennies");
console.log(sports)