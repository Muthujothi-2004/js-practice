// Create an array of 2 colors. Use push() to add 2 more colors in one line and print the new array.

colours=["red","blue"];
colours.push("yellow","black")
console.log(colours)