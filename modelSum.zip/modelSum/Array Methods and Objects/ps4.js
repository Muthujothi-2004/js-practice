// Write a program to find the index of "Laptop" in an array of 3 devices. Print the result.

devices=[ "smartphones","tablets","smart watches","e-readers","Laptop"]
ans=devices.indexOf("Laptop");
console.log(ans);
