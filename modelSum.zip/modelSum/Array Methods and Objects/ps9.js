// Create an array of 2 objects, where each object represents a
// book with properties title and author. Print the title of the first book.
books=[
    {
        title:"gost book",
        author:"ramakrishnan"
    },
    {
        title:"rider fire",
        author:"hari"
    }
]
console.log(books[0].title)