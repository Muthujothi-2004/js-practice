// Create a string "HTML-CSS-JavaScript". Use split() to break it into an array of 3 elements and print the array.

code="HTML-CSS-JavaScript"
a=code.split('-');
console.log(a);