let car={
    model:"tiyota",
    make:"carola",
    year:2020
};
console.log(car.model);