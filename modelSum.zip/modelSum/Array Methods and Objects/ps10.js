// You have an array of 4 objects, each representing a car with properties brand and model.
//  Write a program to add a new property
// year to each object and assign a value, then print the updated array.

mobile=[
    {
        brand:"realme",
        model:"c3"
    },
    {
        brand:"redme",
        model:"c6"
    }
]
mobile[0].year=2020;
mobile[1].year=2876;
console.log(mobile)