
// Create an array of 4 fruits. Use join()
// without any separator to combine the array elements into a single string and print the result.let 
fruits=["apple","banana","cherry","mango"]
console.log(fruits.join());
