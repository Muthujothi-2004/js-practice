// Create an array of 5 fruits. Use shift() to remove the first two fruits, one by one, and print the array after each removal.

fruits=["apple","banana","mango","chery"];

fruits.shift();
console.log(fruits);