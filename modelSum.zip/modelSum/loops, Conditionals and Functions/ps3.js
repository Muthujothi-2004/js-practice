let temperature = 30;
if (temperature<20) {
    console.log("It's cold outside.");
   } else {
    console.log("It's warm outside.");
   }