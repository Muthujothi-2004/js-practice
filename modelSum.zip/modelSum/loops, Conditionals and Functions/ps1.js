calculateArea();
greetUser();

function calculateArea() {
    const radius = 5;
    let area;
    area = Math.PI * radius * radius;
    console.log(area);
}
function greetUser() {
    var userName = "John";
    console.log(userName);

}