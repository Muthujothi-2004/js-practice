let count = 1;
while (count <=100) {
 console.log("Counting down: " + count);
 count = count + 1;
}