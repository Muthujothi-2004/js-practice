function runway(n) {
    switch (n) {
        case 1:
            console.log("RUN WAY NO:1");
            break;

        case 2:
            console.log("RUN WAY NO:2");
            break;

        case 3:
            console.log("RUN WAY NO:3");
            break;

        case 4:
            console.log("RUN WAY NO:4");
            break;

        default:
            console.log("USE TO RED RUNWAY")
            break;
    }
}
runway(5);
