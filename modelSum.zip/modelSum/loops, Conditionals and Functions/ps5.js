function sumNumbers(n){
 let i=0;
 let sum=1;
 while(i<=n){
    sum=sum+i;
    i++;
    
 }
 return sum;
}
console.log(sumNumbers(10))