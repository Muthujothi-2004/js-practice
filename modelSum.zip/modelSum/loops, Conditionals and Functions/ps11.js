function printMultiplicationTable(n,r){
    for(i=r;i>=1;i--){
        mul=n*i;
        console.log(mul)
        
    }
}
printMultiplicationTable(5,6)