function getDayName(n) {
    switch (n) {
        case 1:
            console.log("Monday");
            break;

        case 2:
            console.log("Tuesday");
            break;

        case 3:
            console.log("Wednesday");
            break;

        case 4:
            console.log("Thursday");
            break;

        case 5:
            console.log("friday");
            break;

        case 6:
            console.log("saturday");
            break;

        case 7:
            console.log("sunday");
            break;
    }
}
getDayName(5);