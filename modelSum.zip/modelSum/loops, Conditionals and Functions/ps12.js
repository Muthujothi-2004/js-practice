function lapsaround(n){
    let i=1;
  while(i<=n){
    console.log(i);
    i++;
  }
}
lapsaround(5)