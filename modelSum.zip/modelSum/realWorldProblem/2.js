// You have an array of test scores for 7 students. Write a program to find 
// and print the highest score using the Math.max() function along with the spread operator.

scores=[76,86,38,36,92];
ans=Math.max(...scores);
console.log(ans)